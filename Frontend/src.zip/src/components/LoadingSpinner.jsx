import React from 'react'
import "../css/Spinner.css"

const LoadingSpinner = () => {
  return (
    <span className='loader'></span>
  )
}

export default LoadingSpinner
